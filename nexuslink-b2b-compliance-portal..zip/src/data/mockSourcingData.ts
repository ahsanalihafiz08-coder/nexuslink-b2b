import { B2BComponent, PortData, ComplianceAuditResult } from "../types";

export const MOCK_COMPONENTS: B2BComponent[] = [
  {
    id: "esp32",
    name: "ESP32-WROOM-32E Wi-Fi + BT Module",
    category: "Wireless Telecom Modules",
    suggestedHsCode: "8517.6290",
    basePriceUSD: 1.85,
    moq: 1000,
    leadTimeDays: 14,
    manufacturerPort: "Shenzhen Port (SZX)",
    weightKgPerUnit: 0.008,
    description: "Dual-core microcontroller with integrated Wi-Fi and Bluetooth, widely used in IoT enterprise deployments."
  },
  {
    id: "lifepo4",
    name: "12V 100Ah LiFePO4 Battery Pack",
    category: "Lithium Ion Storage Batteries",
    suggestedHsCode: "8507.6000",
    basePriceUSD: 145.00,
    moq: 50,
    leadTimeDays: 25,
    manufacturerPort: "Ningbo-Zhoushan Port (NGB)",
    weightKgPerUnit: 11.5,
    description: "Deep cycle lithium iron phosphate battery with active smart BMS for green industrial energy storage systems."
  },
  {
    id: "solar-450",
    name: "450W Monocrystalline PV Panel",
    category: "Photosensitive Semiconductor Devices",
    suggestedHsCode: "8541.4300",
    basePriceUSD: 42.50,
    moq: 120,
    leadTimeDays: 20,
    manufacturerPort: "Shenzhen Port (SZX)",
    weightKgPerUnit: 23.0,
    description: "High-efficiency monocrystalline cell solar modules with tempered protective glass for commercial solar arrays."
  },
  {
    id: "lcd-7",
    name: "7.0 Inch TFT LCD Display Panel",
    category: "LCD Liquid Crystal Displays",
    suggestedHsCode: "8528.5900",
    basePriceUSD: 12.80,
    moq: 500,
    leadTimeDays: 18,
    manufacturerPort: "Shenzhen Port (SZX)",
    weightKgPerUnit: 0.28,
    description: "Active matrix TFT display with 1024x600 resolution and capacitive touch digitizer, suitable for HMIs."
  },
  {
    id: "psu-350",
    name: "MeanWell LRS-350-24 Power Supply (24V 14.6A)",
    category: "Static Converters & Power Units",
    suggestedHsCode: "8504.4090",
    basePriceUSD: 16.50,
    moq: 200,
    leadTimeDays: 15,
    manufacturerPort: "Ningbo-Zhoushan Port (NGB)",
    weightKgPerUnit: 0.76,
    description: "Enclosed switching power supply with dual-range input selector, high reliability for automated automation grids."
  }
];

export const MOCK_PORTS: PortData[] = [
  // Export Ports
  {
    id: "port-szx",
    name: "Shenzhen Port",
    code: "SZX",
    country: "China",
    region: "East Asia",
    type: "EXPORT",
    standardPortHandlingFeeUSD: 250,
    typicalTransitDaysFromShenzhen: 0
  },
  {
    id: "port-ngb",
    name: "Ningbo-Zhoushan Port",
    code: "NGB",
    country: "China",
    region: "East Asia",
    type: "EXPORT",
    standardPortHandlingFeeUSD: 280,
    typicalTransitDaysFromShenzhen: 3
  },
  // Import Ports
  {
    id: "port-kap",
    name: "Karachi Port",
    code: "KAP",
    country: "Pakistan",
    region: "South Asia",
    type: "IMPORT",
    standardPortHandlingFeeUSD: 450,
    typicalTransitDaysFromShenzhen: 16
  },
  {
    id: "port-qsm",
    name: "Port Qasim",
    code: "QSM",
    country: "Pakistan",
    region: "South Asia",
    type: "IMPORT",
    standardPortHandlingFeeUSD: 420,
    typicalTransitDaysFromShenzhen: 17
  },
  {
    id: "port-rtm",
    name: "Port of Rotterdam",
    code: "RTM",
    country: "Netherlands",
    region: "Europe",
    type: "IMPORT",
    standardPortHandlingFeeUSD: 600,
    typicalTransitDaysFromShenzhen: 28
  },
  {
    id: "port-lax",
    name: "Port of Los Angeles",
    code: "LAX",
    country: "United States",
    region: "North America",
    type: "IMPORT",
    standardPortHandlingFeeUSD: 750,
    typicalTransitDaysFromShenzhen: 20
  },
  {
    id: "port-dxb",
    name: "Jebel Ali Port",
    code: "DXB",
    country: "United Arab Emirates",
    region: "Middle East",
    type: "IMPORT",
    standardPortHandlingFeeUSD: 500,
    typicalTransitDaysFromShenzhen: 12
  }
];

// Pre-packaged realistic data fallback for standard items to keep the dashboard responsive
export const DEFAULT_COMPLIANCE_MAP: Record<string, ComplianceAuditResult> = {
  esp32: {
    hsCode: "8517.6290",
    dutyRatePercentage: 11,
    regulatoryDutyPercentage: 0,
    salesTaxPercentage: 18,
    additionalCustomsDutyPercentage: 2,
    withholdingTaxPercentage: 6,
    isFtaEligible: true,
    ftaSavingsPercentage: 6, // Base duty reduces from 11% to 5% under China-Pakistan FTA
    requiredDocuments: [
      {
        name: "Bill of Lading (B/L)",
        purpose: "Primary maritime contract of carriage, required to establish legal title and trigger delivery order.",
        urgency: "CRITICAL",
        issuer: "Shipping Line / Ocean Carrier"
      },
      {
        name: "China-Pakistan FTA Certificate of Origin (Form-FTA)",
        purpose: "Official proof that goods originated in Shenzhen, qualifying the shipment for 6% duty reduction.",
        urgency: "CRITICAL",
        issuer: "China Council for the Promotion of International Trade (CCPIT)"
      },
      {
        name: "PTA Type Approval Certificate",
        purpose: "Regulatory clearance for telecommunication and wireless equipment (Wi-Fi/Bluetooth compliance).",
        urgency: "HIGH",
        issuer: "Pakistan Telecommunication Authority"
      },
      {
        name: "Commercial Invoice & Packing List",
        purpose: "Details the commercial transaction value, weights, and detailed breakdown of each model for customs assessment.",
        urgency: "CRITICAL",
        issuer: "Shenzhen Exporter / Supplier"
      }
    ],
    regulatoryComplianceNotes: [
      "Must file E-Form (Form-I) through commercial bank before vessel arrival.",
      "Requires PTA NOC (No Objection Certificate) for wireless components during customs examination.",
      "Customs evaluation will refer to standard valuation rulings for microcontrollers if declared unit prices are unusually low."
    ],
    clearanceSteps: [
      "File Import General Manifest (IGM) upon vessel departure from Shenzhen.",
      "Submit Goods Declaration (GD) electronically through Weboc customs portal.",
      "Provide PTA Type Approval and FTA Certificate of Origin to customs appraiser.",
      "Pay calculated Customs Duties and Sales Tax via bank online payment.",
      "Undergo Customs Physical Examination (Red Channel due to telecom nature).",
      "Acquire Customs Release order, pay Terminal Handling Charges, and gate-out from Karachi Port."
    ],
    riskAssessment: "MODERATE RISK",
    summaryNote: "Importing wireless MCUs requires PTA coordination. Prepare type approval paperwork 10 days before cargo landing at Karachi Port to avoid demurrage."
  },
  lifepo4: {
    hsCode: "8507.6000",
    dutyRatePercentage: 20,
    regulatoryDutyPercentage: 5,
    salesTaxPercentage: 18,
    additionalCustomsDutyPercentage: 4,
    withholdingTaxPercentage: 6,
    isFtaEligible: true,
    ftaSavingsPercentage: 10, // Duty reduced from 20% to 10%
    requiredDocuments: [
      {
        name: "Bill of Lading (B/L)",
        purpose: "Document of title for maritime freight release.",
        urgency: "CRITICAL",
        issuer: "Sino-Agent / Shipping Line"
      },
      {
        name: "UN38.3 Test Report & SDS",
        purpose: "Safety documentation declaring that cells have passed stringent thermal, vibration, and impact tests for Class 9 Dangerous Goods.",
        urgency: "CRITICAL",
        issuer: "CNAS Certified Testing Lab"
      },
      {
        name: "FTA Certificate of Origin",
        purpose: "Enables reduction of base duty by half under CPFTA.",
        urgency: "HIGH",
        issuer: "Ningbo customs / CCPIT"
      }
    ],
    regulatoryComplianceNotes: [
      "Lithium Batteries are classified as Class 9 Dangerous Goods (HAZMAT) requiring special vessel stowage and port segregation.",
      "Ensure inner batteries have clear ratings in Wh and pass drop-test standards."
    ],
    clearanceSteps: [
      "Provide pre-alert shipping advice to shipping agent for hazardous declaration.",
      "Vessel arrivals require early Port Qasim or Karachi Port dangerous cargo yard placement request.",
      "Submit Weboc Goods Declaration with certified UN38.3 test report attached.",
      "Pay customs duties, hazard handling premiums, and terminal tariffs."
    ],
    riskAssessment: "HIGH RISK",
    summaryNote: "Battery shipments face strict safety scrutiny. Ensure safety data sheets are entirely synchronized with shipping labels to prevent severe customs hold ups."
  }
};
